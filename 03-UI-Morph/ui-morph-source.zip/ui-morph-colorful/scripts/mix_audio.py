# /// script
# dependencies = ["numpy"]
# ///
"""Synthesize UI sounds, place each one by its measured peak on the cue time, mix over the song.

usage: uv run scripts/mix_audio.py   (needs audio/beats.json and out/cues.json from render.ts)
writes audio/sfx/*.wav and audio/mix.wav (loops: sound tails past the end wrap to the start)
"""
import json
import os
import subprocess
import wave

import numpy as np

SR = 48000
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rng = np.random.default_rng(7)


def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def env(t, attack, decay):
    a = np.clip(t / attack, 0, 1) if attack > 0 else np.ones_like(t)
    return a * np.exp(-np.maximum(0, t - attack) / decay)


def highpass(x, fc):
    # one-pole high-pass
    rc = 1 / (2 * np.pi * fc)
    a = rc / (rc + 1 / SR)
    y = np.zeros_like(x)
    for i in range(1, len(x)):
        y[i] = a * (y[i - 1] + x[i] - x[i - 1])
    return y


def lowpass(x, fc):
    a = np.exp(-2 * np.pi * fc / SR)
    y = np.zeros_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc = (1 - a) * x[i] + a * acc
        y[i] = acc
    return y


def norm(x, peak):
    return x / (np.abs(x).max() + 1e-9) * peak


def click(freq=2100, dur=0.05, body=0.012, peak=0.5):
    t = t_axis(dur)
    noise = highpass(rng.standard_normal(len(t)), 3000) * env(t, 0.0004, 0.0025)
    tone = np.sin(2 * np.pi * freq * t) * env(t, 0.0008, body)
    return norm(noise * 0.6 + tone, peak)


def sfx():
    s = {}
    s["click"] = click(2100, peak=0.42)
    s["key"] = click(3200, dur=0.035, body=0.006, peak=0.2)
    t = t_axis(0.08)
    s["tick"] = norm(np.sin(2 * np.pi * 2900 * t) * env(t, 0.0006, 0.012) + click(4200, dur=0.08, body=0.004, peak=0.3), 0.2)
    s["press"] = click(1500, body=0.008, peak=0.22)
    s["release"] = click(2500, body=0.006, peak=0.18)
    t = t_axis(0.09)
    thunk = np.sin(2 * np.pi * (700 + 500 * np.exp(-t / 0.01)) * t) * env(t, 0.001, 0.02)
    s["toggle"] = norm(thunk + click(2600, dur=0.09, peak=0.5), 0.45)
    t = t_axis(0.12)
    f = 380 + 700 * (1 - np.exp(-t / 0.02))
    s["pop"] = norm(np.sin(2 * np.pi * np.cumsum(f) / SR) * env(t, 0.004, 0.03), 0.3)
    t = t_axis(0.6)
    n1 = np.sin(2 * np.pi * 1318.5 * t) * env(t, 0.002, 0.12)
    t2 = np.maximum(0, t - 0.075)
    n2 = np.sin(2 * np.pi * 1975.5 * t2) * env(t2, 0.002, 0.18) * (t >= 0.075)
    s["success"] = norm((n1 + n2 * 0.9) + 0.15 * np.sin(2 * np.pi * 2637 * t2) * env(t2, 0.002, 0.08) * (t >= 0.075), 0.26)
    t = t_axis(0.26)
    n = rng.standard_normal(len(t))
    sw = lowpass(highpass(n, 900), 4500) * np.sin(np.pi * np.clip(t / 0.26, 0, 1)) ** 2
    s["swish"] = norm(sw, 0.07)
    return s


def write_wav(path, data):
    data = np.clip(data, -1, 1)
    pcm = (data * 32767).astype(np.int16)
    ch = 1 if data.ndim == 1 else data.shape[1]
    with wave.open(path, "wb") as w:
        w.setnchannels(ch)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def measured_peak(x):
    # peak of the smoothed amplitude envelope, so it lands where the ear hears the hit
    k = int(SR * 0.002)
    e = np.convolve(np.abs(x), np.ones(k) / k, mode="same")
    return int(np.argmax(e))


def main():
    beats = json.load(open(os.path.join(root, "audio/beats.json")))
    cues = json.load(open(os.path.join(root, "out/cues.json")))
    dur = cues["duration"]
    n = int(round(dur * SR))
    print(f"song start={beats['start']:.3f}s dur={dur:.3f}s", flush=True)
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-ss", f"{beats['start']:.5f}", "-t", f"{dur + 0.1:.5f}",
         "-i", os.path.join(root, beats["source"]), "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"],
        check=True, capture_output=True,
    ).stdout
    song = np.frombuffer(raw, dtype=np.float32).reshape(-1, 2)[:n].astype(np.float64)
    song = np.pad(song, ((0, n - len(song)), (0, 0)))
    fade = int(SR * 0.004)
    song[:fade] *= np.linspace(0, 1, fade)[:, None]
    song[-fade:] *= np.linspace(1, 0, fade)[:, None]
    mix = song * 0.8

    os.makedirs(os.path.join(root, "audio/sfx"), exist_ok=True)
    sounds = sfx()
    peaks = {}
    for name, x in sounds.items():
        write_wav(os.path.join(root, f"audio/sfx/{name}.wav"), x)
        peaks[name] = measured_peak(x)
        print(f"sfx {name}: peak at {peaks[name] / SR * 1000:.1f}ms", flush=True)

    for cue in cues["cues"]:
        x = sounds[cue["kind"]]
        start = int(round(cue["t"] * SR)) - peaks[cue["kind"]]
        idx = (start + np.arange(len(x))) % n  # wrap so the loop is seamless
        pan = 0.0 if cue["kind"] != "swish" else 0.25
        mix[idx, 0] += x * (1 - pan)
        mix[idx, 1] += x * (1 + pan)
        print(f"cue {cue['kind']:8s} beat={cue['b']:6.2f} t={cue['t']:.3f}s", flush=True)

    peak = np.abs(mix).max()
    if peak > 0.98:
        mix *= 0.98 / peak
    write_wav(os.path.join(root, "audio/mix.wav"), mix)
    print(f"wrote audio/mix.wav peak={peak:.3f}", flush=True)


if __name__ == "__main__":
    main()
