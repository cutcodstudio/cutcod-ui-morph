# /// script
# dependencies = ["numpy"]
# ///
"""Beat-grid analysis with numpy only.

usage:
  uv run scripts/analyze_audio.py scan audio/candidates/*.mp3
  uv run scripts/analyze_audio.py grid audio/song.mp3 --bars 7 --out audio/beats.json
  uv run scripts/analyze_audio.py peak audio/sfx/click.wav
"""
import json
import subprocess
import sys

import numpy as np

SR = 22050
HOP = 256


def load(path: str, sr: int = SR) -> np.ndarray:
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"],
        check=True,
        capture_output=True,
    ).stdout
    return np.frombuffer(raw, dtype=np.float32).copy()


def onset_envelope(y: np.ndarray) -> np.ndarray:
    n_fft = 1024
    win = np.hanning(n_fft).astype(np.float32)
    frames = 1 + (len(y) - n_fft) // HOP
    idx = np.arange(n_fft)[None, :] + HOP * np.arange(frames)[:, None]
    spec = np.abs(np.fft.rfft(y[idx] * win, axis=1))
    logspec = np.log1p(100 * spec)
    flux = np.maximum(0, np.diff(logspec, axis=0)).sum(axis=1)
    flux = np.concatenate([[0], flux])
    # remove slow trend so the envelope is centered on transients
    k = int(SR / HOP * 0.5)
    trend = np.convolve(flux, np.ones(k) / k, mode="same")
    env = np.maximum(0, flux - trend)
    return env / (env.max() + 1e-9)


def low_band_energy(y: np.ndarray) -> np.ndarray:
    """Per-frame energy below ~150 Hz, used to find kick drums (downbeats)."""
    n_fft = 2048
    win = np.hanning(n_fft).astype(np.float32)
    frames = 1 + (len(y) - n_fft) // HOP
    idx = np.arange(n_fft)[None, :] + HOP * np.arange(frames)[:, None]
    spec = np.abs(np.fft.rfft(y[idx] * win, axis=1))
    cutoff = int(150 / (SR / n_fft))
    return spec[:, 1:cutoff].sum(axis=1)


def estimate_bpm(env: np.ndarray, lo: float = 90, hi: float = 160) -> tuple[float, float]:
    fps = SR / HOP
    ac = np.correlate(env, env, mode="full")[len(env) - 1 :]
    ac /= ac[0] + 1e-9
    best, best_score = 0.0, -1.0
    for bpm in np.arange(lo, hi, 0.05):
        lag = 60 / bpm * fps
        # score multiples of the beat period with linear interpolation
        score = 0.0
        for m in (1, 2, 4):
            l = lag * m
            i = int(l)
            if i + 1 >= len(ac):
                break
            f = l - i
            score += (ac[i] * (1 - f) + ac[i + 1] * f) / m
        if score > best_score:
            best, best_score = bpm, score
    return float(best), float(best_score)


def beat_phase(env: np.ndarray, bpm: float) -> float:
    """Best phase (seconds) of an ideal beat comb against the onset envelope."""
    fps = SR / HOP
    period = 60 / bpm
    t = np.arange(len(env)) / fps
    best, best_score = 0.0, -1.0
    for phase in np.arange(0, period, 0.002):
        times = np.arange(phase, t[-1], period)
        frames = np.round(times * fps).astype(int)
        frames = frames[frames < len(env)]
        score = env[frames].mean()
        if score > best_score:
            best, best_score = phase, score
    return float(best)


def scan(paths: list[str]) -> None:
    for p in paths:
        y = load(p)
        env = onset_envelope(y)
        bpm, score = estimate_bpm(env)
        print(f"{p}\tdur={len(y) / SR:6.1f}s\tbpm={bpm:6.2f}\tscore={score:.3f}", flush=True)


def grid(path: str, bars: int, out: str, bpm_hint: float | None) -> None:
    y = load(path)
    env = onset_envelope(y)
    bpm, _ = estimate_bpm(env)
    if bpm_hint:
        bpm, _ = estimate_bpm(env, bpm_hint - 3, bpm_hint + 3)
    print(f"bpm={bpm:.3f}", flush=True)
    phase = beat_phase(env, bpm)
    period = 60 / bpm
    fps = SR / HOP
    low = low_band_energy(y)
    low /= low.max() + 1e-9
    beats = np.arange(phase, len(y) / SR - period, period)
    beat_frames = np.round(beats * fps).astype(int)
    beat_frames = beat_frames[beat_frames < len(low)]
    beats = beats[: len(beat_frames)]
    n = bars * 4
    # choose which beat of 4 is the downbeat (strongest average kick)
    kick = low[beat_frames]
    downbeat_offset = int(np.argmax([kick[o::4].mean() for o in range(4)]))
    # choose a start downbeat where the next `bars` bars have full energy
    # (skip intros), preferring the loudest, most regular section
    rms = np.array([
        np.sqrt(np.mean(y[int(b * SR) : int((b + period) * SR)] ** 2)) for b in beats
    ])
    best_start, best_score = None, -1.0
    for start in range(downbeat_offset, len(beats) - n, 4):
        section = rms[start : start + n]
        # also need one extra beat so the loop tail is covered
        if start + n + 1 > len(beats):
            break
        score = section.min() * 0.6 + section.mean() * 0.4 + kick[start] * 0.2
        if score > best_score:
            best_start, best_score = start, score
    assert best_start is not None, "song too short"
    start_t = float(beats[best_start])
    # refine tempo + phase on the chosen section only (global fit drifts ~20ms over 8 bars)
    t0 = start_t - 8 * period
    best_fit = None
    for b in np.arange(bpm - 0.5, bpm + 0.5, 0.01):
        p = 60 / b
        for ph in np.arange(-0.03, 0.03, 0.001):
            fr = (t0 + ph + np.arange(n + 16) * p) * fps
            i = fr.astype(int)
            f = fr - i
            s = (env[i] * (1 - f) + env[i + 1] * f).sum()
            if best_fit is None or s > best_fit[0]:
                best_fit = (s, b, ph)
    _, bpm, ph = best_fit
    period = 60 / bpm
    start_t = t0 + ph + 8 * period
    beats = start_t + (np.arange(len(beats)) - best_start) * period
    print(f"phase={phase:.3f}s downbeat_offset={downbeat_offset} start_beat={best_start} start={start_t:.3f}s", flush=True)
    data = {
        "source": path,
        "bpm": bpm,
        "beat": period,
        "bars": bars,
        "start": start_t,
        "duration": n * period,
        # beat times relative to the clip start
        "beats": [round(float(b - start_t), 4) for b in beats[best_start : best_start + n + 1]],
    }
    with open(out, "w") as f:
        json.dump(data, f, indent=2)
    print(f"wrote {out}", flush=True)


def peak(path: str) -> None:
    y = load(path, 48000)
    env = np.abs(y)
    print(json.dumps({"path": path, "peak": float(np.argmax(env) / 48000), "dur": len(y) / 48000}))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "scan":
        scan(sys.argv[2:])
    elif cmd == "grid":
        args = sys.argv[2:]
        path = args[0]
        bars = int(args[args.index("--bars") + 1]) if "--bars" in args else 7
        out = args[args.index("--out") + 1] if "--out" in args else "audio/beats.json"
        hint = float(args[args.index("--bpm") + 1]) if "--bpm" in args else None
        grid(path, bars, out, hint)
    elif cmd == "peak":
        for p in sys.argv[2:]:
            peak(p)
