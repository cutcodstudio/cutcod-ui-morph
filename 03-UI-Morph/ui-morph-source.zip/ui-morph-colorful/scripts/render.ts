// Renders index.html by calling seek(t) for every subframe with Playwright.
//
//   bun scripts/render.ts beats   -> out/beats.png, one frame per beat (check the grid first)
//   bun scripts/render.ts still 3.2 -> out/still.png at t seconds
//   bun scripts/render.ts full    -> out/motion.mp4, 60fps, 4 subframes blended with tmix
//
// Reads the measured beat grid from audio/beats.json and exports cues to out/cues.json
// so scripts/mix_audio.py can place every UI sound by its peak.
import { chromium, type Page } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { pathToFileURL } from 'node:url'

const root = path.resolve(import.meta.dirname, '..')
const outDir = path.join(root, 'out')
const framesDir = path.join(root, 'tmp', 'frames')
const FPS = 60
const SUB = 4
const WORKERS = Number(process.env.WORKERS || 6)

const beats = JSON.parse(fs.readFileSync(path.join(root, 'audio', 'beats.json'), 'utf8')) as { beat: number }

function run(cmd: string, args: string[]) {
  return new Promise<void>((resolve, reject) => {
    console.log(`$ ${cmd} ${args.join(' ')}`)
    const p = spawn(cmd, args, { stdio: 'inherit' })
    p.on('error', reject)
    p.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} exited ${code}`))))
  })
}

async function openPage(browser: Awaited<ReturnType<typeof chromium.launch>>): Promise<Page> {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1440 }, deviceScaleFactor: 1 })
  await page.addInitScript(() => {
    ;(window as any).__RENDER__ = true
  })
  page.on('pageerror', (e) => console.error('pageerror', e))
  await page.goto(pathToFileURL(path.join(root, 'index.html')).href)
  await page.evaluate(() => document.fonts.ready)
  await page.evaluate((beat) => (window as any).configure({ beat }), beats.beat)
  return page
}

async function shot(page: Page, t: number, file: string) {
  await page.evaluate((tt) => (window as any).seek(tt), t)
  await page.locator('#stage').screenshot({ path: file, type: 'png', animations: 'disabled' })
}

async function main() {
  const mode = process.argv[2] || 'beats'
  fs.mkdirSync(outDir, { recursive: true })
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_EXECUTABLE || undefined })
  const first = await openPage(browser)
  const tl = await first.evaluate(() => (window as any).timeline())
  fs.writeFileSync(path.join(outDir, 'cues.json'), JSON.stringify(tl, null, 2))
  console.log(`beat=${tl.beat.toFixed(4)}s duration=${tl.duration.toFixed(3)}s cues=${tl.cues.length}`)

  if (mode === 'still') {
    const t = Number(process.argv[3] || 0)
    await shot(first, t, path.join(outDir, 'still.png'))
    console.log('wrote out/still.png')
  } else if (mode === 'beats') {
    // one frame per beat, sampled late in the beat so the state has settled
    const dir = path.join(root, 'tmp', 'beats')
    fs.rmSync(dir, { recursive: true, force: true })
    fs.mkdirSync(dir, { recursive: true })
    const offset = Number(process.argv[3] ?? 0.7)
    for (let b = 0; b < tl.beats; b++) {
      await shot(first, (b + offset) * tl.beat, path.join(dir, `${String(b).padStart(2, '0')}.png`))
      console.log(`beat ${b}`)
    }
    await run('ffmpeg', ['-v', 'error', '-y', '-framerate', '1', '-i', path.join(dir, '%02d.png'),
      '-vf', 'scale=360:360,tile=8x4', '-frames:v', '1', path.join(outDir, 'beats.png')])
    console.log('wrote out/beats.png')
  } else if (mode === 'full') {
    fs.rmSync(framesDir, { recursive: true, force: true })
    fs.mkdirSync(framesDir, { recursive: true })
    const frames = Math.round(tl.duration * FPS)
    const total = frames * SUB
    const pages = [first, ...(await Promise.all(Array.from({ length: WORKERS - 1 }, () => openPage(browser))))]
    let done = 0
    const started = Date.now()
    await Promise.all(pages.map(async (page, w) => {
      for (let i = w; i < total; i += WORKERS) {
        // subframes centered on each output frame: shutter spans one full frame
        const t = (i - (SUB - 1) / 2) / (FPS * SUB)
        await shot(page, t, path.join(framesDir, `${String(i).padStart(6, '0')}.png`))
        done++
        if (done % 200 === 0) console.log(`subframe ${done}/${total} (${((Date.now() - started) / 1000).toFixed(0)}s)`)
      }
    }))
    console.log(`rendered ${total} subframes`)
    const audio = path.join(root, 'audio', 'mix.wav')
    const hasAudio = fs.existsSync(audio)
    await run('ffmpeg', [
      '-v', 'error', '-y', '-framerate', String(FPS * SUB), '-i', path.join(framesDir, '%06d.png'),
      ...(hasAudio ? ['-i', audio] : []),
      '-vf', `tmix=frames=${SUB},select='eq(mod(n,${SUB}),${SUB - 1})',setpts=N/(${FPS}*TB)`,
      '-r', String(FPS), '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-pix_fmt', 'yuv420p',
      ...(hasAudio ? ['-af', `apad=whole_dur=${frames / FPS}`, '-c:a', 'aac', '-b:a', '256k'] : []),
      '-movflags', '+faststart', path.join(outDir, 'motion.mp4'),
    ])
    console.log('wrote out/motion.mp4')
  }
  await browser.close()
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
