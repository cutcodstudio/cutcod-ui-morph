# ui-morph-colorful

One shape, never cut, 8 bars at 125 BPM. Every section floods a new canvas color from the cursor, and the shape floods its own color the same way, so no transition passes through gray. Rendered from one HTML file where every style is a pure function of time (`seek(t)`). No Remotion, no After Effects.

States: reactions → star rating drag → guest stepper → calendar range → hue picker drag (the canvas follows the hue live) → pricing switch → upload ring → avatar group → notification stack → reactions.

```
index.html               the whole animation: closed-form springs, cyclic tracks, color floods, seek(t)
scripts/analyze_audio.py numpy beat grid (tempo, phase, downbeat, section refine)
scripts/mix_audio.py     synthesized UI sounds, placed by measured peak, mixed over the song
scripts/render.ts        Playwright: 4 subframes per frame -> ffmpeg tmix -> 60fps mp4
```

## Render

```bash
bun install
uv run scripts/analyze_audio.py grid audio/song.mp3 --bars 8 --bpm 125 --out audio/beats.json
bun scripts/render.ts beats      # out/beats.png, one frame per beat
uv run scripts/mix_audio.py      # audio/mix.wav (needs out/cues.json from the step above)
bun scripts/render.ts full       # out/motion.mp4
```

Music: "Disco Ain't Old School" from Mixkit (free license), https://assets.mixkit.co/music/935/935.mp3
