# 还原说明

来源：https://gist.github.com/remorses/3d467b50a0519ef7859823046dc9c427

Gist 修订：e88abbe3dedc109dbe1c074133d920c0af0cde94。

本包保留原动画逻辑、配色、时间轴、弹簧函数与音效合成代码。输出为 1440×1440、60 fps、H.264 / AAC 视频；922 帧，约 15.37 秒。每输出帧由 4 个子帧合成，共 3688 个子帧。节拍为 124.98 BPM，配乐片段起于 26.851626 秒，音轨长 15.362458 秒。

## 本次补齐和修复

- 将 Gist 扁平文件恢复为原文档要求的 scripts/、audio/、assets/fonts/ 目录。
- 从 Vercel 官方仓库补齐 Geist / Geist Mono 可变字体，附许可证和 FONT-SOURCES.md。
- 从原 README 指定的 Mixkit 音乐重新分析节拍，混合 34 个声音事件。附生成的 audio/mix.wav，可直接再次导出视频。
- 用 pathToFileURL 处理 Windows 文件路径；简化 FFmpeg 滤镜转义；增加子进程启动错误处理。
- 音轨末尾补约 4.2 毫秒静音以对齐 922 帧时长，避免原脚本 -shortest 截去最后一帧。
- 导出脚本支持可选 CHROMIUM_EXECUTABLE 环境变量，以复用现有 Chromium。
- 修复原 HTML 在小窗口预览时的居中与裁切问题；此修复不影响导出画面。
- Windows 上 Bun 启动 Playwright 曾挂起，本次使用 Node.js 24 执行 TypeScript 导出脚本。

未取得作者的原始 MP4，无法验证逐像素一致。原代码声明 Apple Color Emoji，本次在 Windows 渲染，表情采用本机字体回退。原 Gist 未给出字体版本，补齐的官方字体可能与作者版本略有差异。

## 预览与重新导出

直接在浏览器打开 index.html 可预览循环动画（HTML 原生预览不播放音乐）。

需要安装 Node.js 24+、Bun 和 FFmpeg，并保证 ffmpeg 命令在 PATH 中。然后在项目目录执行：

```powershell
bun install --frozen-lockfile
bunx playwright install chromium
node scripts/render.ts beats
node scripts/render.ts full
```

输出为 out/motion.mp4。若复用本机已有的 Chromium，可先设置：

```powershell
$env:CHROMIUM_EXECUTABLE = '已有 Chromium 可执行文件的绝对路径'
```

## 修改音轨后重新混音

本源码包未附整首原始配乐；附带的是用于此动画的混音片段。需要重新分析或混音时，先取回原 README 指定音乐，并安装 uv：

```powershell
Invoke-WebRequest 'https://assets.mixkit.co/music/935/935.mp3' -OutFile 'audio/song.mp3'
uv run scripts/analyze_audio.py grid audio/song.mp3 --bars 8 --bpm 125 --out audio/beats.json
node scripts/render.ts beats
uv run scripts/mix_audio.py
node scripts/render.ts full
```

音乐：Mixkit — Disco Ain't Old School。原始代码、音乐与字体的来源及权利分别归其作者；原 README 保留在 README.md。
