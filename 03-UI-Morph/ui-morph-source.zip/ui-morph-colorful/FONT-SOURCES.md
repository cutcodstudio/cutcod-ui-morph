# Restored font assets

The Gist references `assets/fonts/geist.woff2` and `assets/fonts/geist-mono.woff2` with CSS weight range 100–900, but does not include those files. Both files were restored from the official [vercel/geist-font](https://github.com/vercel/geist-font) repository at commit `10dc7658f13c38a474cde201bb09a4617267545b` (2026-06-01), fetched through the GitHub contents API using `gh`.

| Local filename | Official source | Embedded font version |
| --- | --- | --- |
| `work/ui-morph-colorful/assets/fonts/geist.woff2` | [Geist variable WOFF2](https://github.com/vercel/geist-font/blob/10dc7658f13c38a474cde201bb09a4617267545b/fonts/Geist/webfonts/Geist%5Bwght%5D.woff2) | 1.800 |
| `work/ui-morph-colorful/assets/fonts/geist-mono.woff2` | [Geist Mono variable WOFF2](https://github.com/vercel/geist-font/blob/10dc7658f13c38a474cde201bb09a4617267545b/fonts/GeistMono/webfonts/GeistMono%5Bwght%5D.woff2) | 1.700 |

The files were copied without modification. FontTools inspection verified that both contain an `fvar` weight axis with minimum 100, default 400, and maximum 900. This covers the original animation's declared range and intermediate weights such as 650.

Both official license files, `OFL.txt` and `LICENSE.txt`, are included alongside the fonts. The fonts use SIL Open Font License 1.1. The Gist does not identify its original font build, so these official versions cannot be guaranteed to be byte-identical to the author's originals. No animation code was changed.
